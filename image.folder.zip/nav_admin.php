<?php
include("connect.php");
?>
		<!doctype html>
		<html>
			<head>
				<title></title>
			</head>
					<body>
						<p>
							<a href="adminPage.php">Admin Home Page</a>|
							<a href="display.php">Show train List </a>|
							<a href="insert.php">Insert </a>|
							<a href="delete.php">Delete</a>|
							<a href="update.php">update</a>|
							<a href="login(user,admin).php">logout</a>
						</p>
					</body>
		</html>