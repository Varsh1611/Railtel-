<!doctype html>
		<html>
			<head>
				<title></title>
				<style>
				body
				{
					
					
					margin: 0px;
					padding: 0px;
					font-family: cursive;
				}
				
				
				
	p{
		text-align: center; 
		margin:0 ;
		padding:10px;
		color: white;
		background-color: purple;
		list-style-type: none;
		}
		
	 a:hover 
	 {
		background-color: grey;
		color: black;
		border-radius: 50%;
	}
	a{
		color: white;
		 font-size: 25px;
    font-family: cursive;
    margin: 10px;
    padding: 10px;
		
	}
	.box
	{
		position: absolute;
		top:50%;
		left:50%;
		transform: translate(-50%,-50%);
		 ;
		margin:20px auto;
		text-align:center;
		border:4px solid purple;
		padding: 14px 100px;
		width:200px;
		color: black;
		border-radius:24px;
		
	}
				</style>
			</head>
					<body>
					</body>
					</html>