<!doctype html>
		<html>
			<head>
				<title></title>
				<style>
				h1{	text-align:center;}
				body
{
	margin:0;
	padding:10px;
	font-family:sans-serif;
	text-align:center;
}
.table
{
	width:100%;
	border_collapse:collapse;
}
.table td,.table th
{
	padding:12px 15px;
	border:2px solid black;
	text-align:center;
	font-size:16px;
}
.table th
{
	background-color:purple;
	color:white;
}
.table tr:nth-child(even)
{
	background-color:grey;
}
</style>
			</head>
					<body>
					</body>
					</html>