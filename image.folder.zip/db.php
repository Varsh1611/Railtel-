<?php 
$host="localhost";
	 $username="root";
	 $password="";
	 $database="login";
	 
	 // connect to mysql database
	 
	 $conn= mysqli_connect($host,$username,$password,$database);
	 // check connection 
?>