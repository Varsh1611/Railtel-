<!DOCTYPE html>
<html>
	<head>
<title>login page</title>
<meta charset ="utf-8">
<meta name ="viewport"
content="width=device-width, initial-scale=1">
<style> 
BODY  { 
margin : 0;
padding: 0;
background-image:url('gg.jpg');
background-size: cover;
background-attachement: fixed;
text-align:center;

}

.box{
width:300px;
padding:40px;
position: absolute;
top:50%;
left:50%;
transform: translate(-50%,-50%);
background-image:url('ee.jpg');
background-size: cover;
background-attachement: fixed;


}
.box h1{
color:white;
text-transform:uppercase;
font-weight:500;
}
.box input[type="text"],.box input[type="password"]
{
border:0;
background-none;
display: block;
margin:20px auto;
text-align:center;
border:4px solid purple;
padding: 14px 10px;
width:200px;
outline:none;
color: black;
border-radius:24px;
transition:0.25s;
}
.box input[type="text"]:focus,.box input[type="password"]:focus,.box input[type="Login"]:focus{
width:280px;
border-color: cyan;
}
a{
	color:white;
}
</style>
 
 </head> 
<body></body>
</html>
